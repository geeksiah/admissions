<?php
/**
 * Owner Admin System Installer
 * Simple installation script for the owner admin system
 */

// Check if already installed
if (file_exists('config/installed.lock')) {
    die('System already installed. Please remove config/installed.lock to reinstall.');
}

$step = $_GET['step'] ?? 1;
$error = '';
$success = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($step) {
        case 2:
            // Database configuration
            $db_host = $_POST['db_host'] ?? '';
            $db_name = $_POST['db_name'] ?? '';
            $db_user = $_POST['db_user'] ?? '';
            $db_pass = $_POST['db_pass'] ?? '';
            
            if (empty($db_host) || empty($db_name) || empty($db_user)) {
                $error = 'Please fill in all required database fields.';
            } else {
                try {
                    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    
                    // Store database config
                    $_SESSION['db_config'] = [
                        'host' => $db_host,
                        'dbname' => $db_name,
                        'username' => $db_user,
                        'password' => $db_pass
                    ];
                    
                    $success = 'Database connection successful!';
                    $step = 3;
                } catch (PDOException $e) {
                    $error = 'Database connection failed: ' . $e->getMessage();
                }
            }
            break;
            
        case 3:
            // Admin user creation
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $password_confirm = $_POST['password_confirm'] ?? '';
            
            if (empty($username) || empty($password)) {
                $error = 'Please fill in all required fields.';
            } elseif ($password !== $password_confirm) {
                $error = 'Passwords do not match.';
            } elseif (strlen($password) < 8) {
                $error = 'Password must be at least 8 characters long.';
            } else {
                $_SESSION['admin_user'] = [
                    'username' => $username,
                    'password' => password_hash($password, PASSWORD_DEFAULT)
                ];
                
                $success = 'Admin user created successfully!';
                $step = 4;
            }
            break;
            
        case 4:
            // Finalize installation
            try {
                $db_config = $_SESSION['db_config'];
                $admin_user = $_SESSION['admin_user'];
                
                $pdo = new PDO(
                    "mysql:host={$db_config['host']};dbname={$db_config['dbname']};charset=utf8mb4",
                    $db_config['username'],
                    $db_config['password'],
                    [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false
                    ]
                );
                
                // Import database schema
                $schema = file_get_contents('database/schema.sql');
                $pdo->exec($schema);
                
                // Create admin user
                $stmt = $pdo->prepare("
                    INSERT INTO owner_users (username, password_hash, role, status) 
                    VALUES (?, ?, 'admin', 'active')
                ");
                $stmt->execute([$admin_user['username'], $admin_user['password']]);
                
                // Create installed.lock file
                if (!is_dir('config')) {
                    mkdir('config', 0755, true);
                }
                file_put_contents('config/installed.lock', date('Y-m-d H:i:s'));
                
                // Clear session data
                unset($_SESSION['db_config']);
                unset($_SESSION['admin_user']);
                
                $success = 'Installation completed successfully!';
                $step = 5;
                
            } catch (Exception $e) {
                $error = 'Installation failed: ' . $e->getMessage();
            }
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Owner Admin System - Installation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white text-center">
                        <h3 class="mb-0">Owner Admin System Installation</h3>
                    </div>
                    <div class="card-body">
                        <div class="progress mb-4">
                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo ($step / 5) * 100; ?>%;">
                                Step <?php echo $step; ?> of 5
                            </div>
                        </div>
                        
                        <?php if ($error): ?>
                            <div class="alert alert-danger" role="alert">
                                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success" role="alert">
                                <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($step == 1): ?>
                            <h4>Welcome to Owner Admin System</h4>
                            <p>This installer will help you set up the Owner Admin System for managing licenses and monitoring installations.</p>
                            
                            <h5>System Requirements:</h5>
                            <ul>
                                <li>PHP 8.1 or higher</li>
                                <li>MySQL 5.7 or higher</li>
                                <li>Web server (Apache/Nginx)</li>
                                <li>SSL certificate (recommended)</li>
                            </ul>
                            
                            <h5>Features:</h5>
                            <ul>
                                <li>License generation and management</li>
                                <li>Real-time installation monitoring</li>
                                <li>Performance analytics</li>
                                <li>Alert system</li>
                                <li>Revenue tracking</li>
                            </ul>
                            
                            <div class="text-center mt-4">
                                <a href="?step=2" class="btn btn-primary btn-lg">
                                    <i class="fas fa-arrow-right"></i> Start Installation
                                </a>
                            </div>
                            
                        <?php elseif ($step == 2): ?>
                            <h4>Database Configuration</h4>
                            <p>Please provide your database connection details.</p>
                            
                            <form method="POST">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="db_host" class="form-label">Database Host *</label>
                                            <input type="text" class="form-control" id="db_host" name="db_host" value="localhost" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="db_name" class="form-label">Database Name *</label>
                                            <input type="text" class="form-control" id="db_name" name="db_name" value="owner_admin" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="db_user" class="form-label">Database Username *</label>
                                            <input type="text" class="form-control" id="db_user" name="db_user" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="db_pass" class="form-label">Database Password</label>
                                            <input type="password" class="form-control" id="db_pass" name="db_pass">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="text-center mt-4">
                                    <a href="?step=1" class="btn btn-secondary me-2">
                                        <i class="fas fa-arrow-left"></i> Back
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-arrow-right"></i> Continue
                                    </button>
                                </div>
                            </form>
                            
                        <?php elseif ($step == 3): ?>
                            <h4>Admin User Creation</h4>
                            <p>Create the first admin user for the system.</p>
                            
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username *</label>
                                    <input type="text" class="form-control" id="username" name="username" required>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Password *</label>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                    <div class="form-text">Password must be at least 8 characters long.</div>
                                </div>
                                <div class="mb-3">
                                    <label for="password_confirm" class="form-label">Confirm Password *</label>
                                    <input type="password" class="form-control" id="password_confirm" name="password_confirm" required>
                                </div>
                                
                                <div class="text-center mt-4">
                                    <a href="?step=2" class="btn btn-secondary me-2">
                                        <i class="fas fa-arrow-left"></i> Back
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-arrow-right"></i> Continue
                                    </button>
                                </div>
                            </form>
                            
                        <?php elseif ($step == 4): ?>
                            <h4>Finalizing Installation</h4>
                            <p>Please wait while we complete the installation...</p>
                            
                            <form method="POST">
                                <div class="text-center mt-4">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-cog fa-spin"></i> Complete Installation
                                    </button>
                                </div>
                            </form>
                            
                        <?php elseif ($step == 5): ?>
                            <h4>Installation Complete!</h4>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle"></i> 
                                The Owner Admin System has been successfully installed.
                            </div>
                            
                            <h5>Next Steps:</h5>
                            <ol>
                                <li>Delete or rename the <code>install.php</code> file for security</li>
                                <li>Access the admin panel using your credentials</li>
                                <li>Configure your license server settings</li>
                                <li>Start creating licenses for your customers</li>
                            </ol>
                            
                            <div class="text-center mt-4">
                                <a href="index.php" class="btn btn-primary btn-lg">
                                    <i class="fas fa-sign-in-alt"></i> Access Admin Panel
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>