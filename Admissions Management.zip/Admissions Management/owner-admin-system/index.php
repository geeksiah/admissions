<?php
/**
 * Owner Admin System
 * Main entry point for the owner admin system
 */

// Start session
session_start();

// Check if system is installed
if (!file_exists('config/installed.lock')) {
    header('Location: install.php');
    exit;
}

// Autoload classes
spl_autoload_register(function ($class) {
    $paths = [
        __DIR__ . '/classes/',
    ];
    foreach ($paths as $path) {
        $file = $path . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Load configuration
require_once 'config/database.php';

// Initialize database connection
try {
    $database = new Database();
    $pdo = $database->getConnection();
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle authentication
$auth = new OwnerAuth($pdo);
$isAuthenticated = false;
$currentUser = null;

// Check if user is logged in
if (isset($_SESSION['owner_user_id'])) {
    $isAuthenticated = true;
    $currentUser = [
        'id' => $_SESSION['owner_user_id'],
        'username' => $_SESSION['owner_username'],
        'role' => $_SESSION['owner_role']
    ];
}

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $result = $auth->authenticate($username, $password);
    
    if ($result['success']) {
        $_SESSION['owner_user_id'] = $result['user']['id'];
        $_SESSION['owner_username'] = $result['user']['username'];
        $_SESSION['owner_role'] = $result['user']['role'];
        
        $isAuthenticated = true;
        $currentUser = $result['user'];
    } else {
        $loginError = $result['error'];
    }
}

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header('Location: index.php');
    exit;
}

// Get current page
$page = $_GET['page'] ?? 'dashboard';

// If not authenticated, show login form
if (!$isAuthenticated) {
    include 'views/login.php';
    exit;
}

// Include the requested page
$pageFile = "views/{$page}.php";
if (file_exists($pageFile)) {
    include $pageFile;
} else {
    include 'views/dashboard.php';
}
?>
