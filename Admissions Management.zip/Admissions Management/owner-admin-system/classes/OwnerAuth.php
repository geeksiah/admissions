<?php
/**
 * Owner Authentication
 * Handles authentication for the owner admin system
 */

class OwnerAuth {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Authenticate user
     */
    public function authenticate($username, $password) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT id, username, password_hash, role, status 
                FROM owner_users 
                WHERE username = ? AND status = 'active'
            ");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password_hash'])) {
                // Update last login
                $stmt = $this->pdo->prepare("
                    UPDATE owner_users SET last_login = NOW() WHERE id = ?
                ");
                $stmt->execute([$user['id']]);
                
                return [
                    'success' => true,
                    'user' => [
                        'id' => $user['id'],
                        'username' => $user['username'],
                        'role' => $user['role']
                    ]
                ];
            }
            
            return ['success' => false, 'error' => 'Invalid credentials'];
            
        } catch (Exception $e) {
            error_log("Authentication error: " . $e->getMessage());
            return ['success' => false, 'error' => 'Authentication failed'];
        }
    }
    
    /**
     * Validate token
     */
    public function validateToken($token) {
        // Simple token validation - in production use JWT or similar
        try {
            $stmt = $this->pdo->prepare("
                SELECT id, username, role, status 
                FROM owner_users 
                WHERE password_hash = ? AND status = 'active'
            ");
            $stmt->execute([$token]);
            $user = $stmt->fetch();
            
            return $user ? true : false;
            
        } catch (Exception $e) {
            error_log("Token validation error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Create user
     */
    public function createUser($username, $password, $role = 'viewer') {
        try {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $this->pdo->prepare("
                INSERT INTO owner_users (username, password_hash, role, status) 
                VALUES (?, ?, ?, 'active')
            ");
            $stmt->execute([$username, $hashedPassword, $role]);
            
            return ['success' => true, 'user_id' => $this->pdo->lastInsertId()];
            
        } catch (Exception $e) {
            error_log("User creation error: " . $e->getMessage());
            return ['success' => false, 'error' => 'User creation failed'];
        }
    }
    
    /**
     * Update user
     */
    public function updateUser($userId, $data) {
        try {
            $updates = [];
            $values = [];
            
            if (isset($data['username'])) {
                $updates[] = "username = ?";
                $values[] = $data['username'];
            }
            
            if (isset($data['password'])) {
                $updates[] = "password_hash = ?";
                $values[] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
            
            if (isset($data['role'])) {
                $updates[] = "role = ?";
                $values[] = $data['role'];
            }
            
            if (isset($data['status'])) {
                $updates[] = "status = ?";
                $values[] = $data['status'];
            }
            
            if (empty($updates)) {
                return ['success' => false, 'error' => 'No updates provided'];
            }
            
            $values[] = $userId;
            
            $stmt = $this->pdo->prepare("
                UPDATE owner_users SET " . implode(', ', $updates) . " 
                WHERE id = ?
            ");
            $stmt->execute($values);
            
            return ['success' => true];
            
        } catch (Exception $e) {
            error_log("User update error: " . $e->getMessage());
            return ['success' => false, 'error' => 'User update failed'];
        }
    }
    
    /**
     * Delete user
     */
    public function deleteUser($userId) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM owner_users WHERE id = ?");
            $stmt->execute([$userId]);
            
            return ['success' => true];
            
        } catch (Exception $e) {
            error_log("User deletion error: " . $e->getMessage());
            return ['success' => false, 'error' => 'User deletion failed'];
        }
    }
    
    /**
     * Get all users
     */
    public function getAllUsers() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT id, username, role, status, last_login, created_at 
                FROM owner_users 
                ORDER BY created_at DESC
            ");
            $stmt->execute();
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            error_log("Get users error: " . $e->getMessage());
            return [];
        }
    }
}
?>
