<?php
/**
 * License Server
 * Central license management and validation
 */

class LicenseServer {
    private $pdo;
    private $encryptionKey;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->encryptionKey = $this->getEncryptionKey();
    }
    
    /**
     * Get encryption key
     */
    private function getEncryptionKey() {
        $stmt = $this->pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'encryption_key'");
        $stmt->execute();
        $result = $stmt->fetch();
        
        if (!$result || empty($result['setting_value'])) {
            // Generate new encryption key
            $key = base64_encode(random_bytes(32));
            $stmt = $this->pdo->prepare("
                INSERT INTO system_settings (setting_key, setting_value, setting_type) 
                VALUES ('encryption_key', ?, 'string')
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
            ");
            $stmt->execute([$key]);
            return $key;
        }
        
        return $result['setting_value'];
    }
    
    /**
     * Generate license key
     */
    public function generateLicenseKey($customerInfo) {
        $licenseData = [
            'customer_id' => $customerInfo['customer_id'],
            'customer_name' => $customerInfo['customer_name'],
            'license_type' => $customerInfo['license_type'],
            'max_users' => $customerInfo['max_users'],
            'max_applications' => $customerInfo['max_applications'],
            'expiry_date' => $customerInfo['expiry_date'],
            'features' => $customerInfo['features'] ?? [],
            'issued_at' => time(),
            'version' => '1.0.0'
        ];
        
        $jsonData = json_encode($licenseData);
        $encryptedData = $this->encrypt($jsonData);
        $signature = $this->sign($encryptedData);
        
        $licenseKey = base64_encode($encryptedData . '|' . $signature);
        
        // Store in database
        $this->storeLicense($licenseKey, $licenseData);
        
        return $licenseKey;
    }
    
    /**
     * Validate license
     */
    public function validateLicense($data) {
        try {
            $licenseKey = $data['license_key'] ?? '';
            $hardwareId = $data['hardware_id'] ?? '';
            $domain = $data['domain'] ?? '';
            $version = $data['version'] ?? '';
            
            if (empty($licenseKey) || empty($hardwareId)) {
                return ['valid' => false, 'error' => 'Missing required parameters'];
            }
            
            // Get license from database
            $stmt = $this->pdo->prepare("
                SELECT * FROM licenses 
                WHERE license_key = ? AND status = 'active'
            ");
            $stmt->execute([$licenseKey]);
            $license = $stmt->fetch();
            
            if (!$license) {
                return ['valid' => false, 'error' => 'License not found'];
            }
            
            // Check expiry
            if (strtotime($license['expiry_date']) < time()) {
                return ['valid' => false, 'error' => 'License expired'];
            }
            
            // Check hardware binding
            if ($license['hardware_id'] !== $hardwareId) {
                return ['valid' => false, 'error' => 'Hardware mismatch'];
            }
            
            // Check domain binding (if applicable)
            if (!empty($license['allowed_domains'])) {
                $allowedDomains = json_decode($license['allowed_domains'], true);
                if (!in_array($domain, $allowedDomains)) {
                    return ['valid' => false, 'error' => 'Domain not authorized'];
                }
            }
            
            // Update last validation
            $stmt = $this->pdo->prepare("
                UPDATE licenses SET 
                    last_validation = NOW(),
                    validation_count = validation_count + 1
                WHERE license_key = ?
            ");
            $stmt->execute([$licenseKey]);
            
            // Log validation
            $this->logValidation($licenseKey, $hardwareId, $domain, $version, true);
            
            return [
                'valid' => true,
                'license_data' => [
                    'customer_id' => $license['customer_id'],
                    'customer_name' => $license['customer_name'],
                    'license_type' => $license['license_type'],
                    'max_users' => $license['max_users'],
                    'max_applications' => $license['max_applications'],
                    'expiry_date' => $license['expiry_date'],
                    'features' => json_decode($license['features'], true)
                ]
            ];
            
        } catch (Exception $e) {
            error_log("License validation error: " . $e->getMessage());
            return ['valid' => false, 'error' => 'Validation failed'];
        }
    }
    
    /**
     * Activate license
     */
    public function activateLicense($data) {
        try {
            $licenseKey = $data['license_key'] ?? '';
            $hardwareId = $data['hardware_id'] ?? '';
            $domain = $data['domain'] ?? '';
            $version = $data['version'] ?? '';
            
            if (empty($licenseKey) || empty($hardwareId)) {
                return ['success' => false, 'error' => 'Missing required parameters'];
            }
            
            // Check if license exists and is available
            $stmt = $this->pdo->prepare("
                SELECT * FROM licenses 
                WHERE license_key = ? AND status = 'active'
            ");
            $stmt->execute([$licenseKey]);
            $license = $stmt->fetch();
            
            if (!$license) {
                return ['success' => false, 'error' => 'License not found'];
            }
            
            // Check if already activated on different hardware
            if (!empty($license['hardware_id']) && $license['hardware_id'] !== $hardwareId) {
                return ['success' => false, 'error' => 'License already activated on different hardware'];
            }
            
            // Update license with hardware binding
            $stmt = $this->pdo->prepare("
                UPDATE licenses SET 
                    hardware_id = ?,
                    domain = ?,
                    version = ?,
                    activated_at = NOW(),
                    last_validation = NOW()
                WHERE license_key = ?
            ");
            $stmt->execute([$hardwareId, $domain, $version, $licenseKey]);
            
            // Log activation
            $this->logActivation($licenseKey, $hardwareId, $domain, $version);
            
            return ['success' => true, 'message' => 'License activated successfully'];
            
        } catch (Exception $e) {
            error_log("License activation error: " . $e->getMessage());
            return ['success' => false, 'error' => 'Activation failed'];
        }
    }
    
    /**
     * Get license status
     */
    public function getLicenseStatus($licenseKey) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    l.*,
                    c.customer_name,
                    c.customer_email,
                    c.customer_phone
                FROM licenses l
                LEFT JOIN customers c ON l.customer_id = c.id
                WHERE l.license_key = ?
            ");
            $stmt->execute([$licenseKey]);
            $license = $stmt->fetch();
            
            if (!$license) {
                return ['error' => 'License not found'];
            }
            
            return [
                'license_key' => $license['license_key'],
                'customer_name' => $license['customer_name'],
                'customer_email' => $license['customer_email'],
                'license_type' => $license['license_type'],
                'status' => $license['status'],
                'expiry_date' => $license['expiry_date'],
                'hardware_id' => $license['hardware_id'],
                'domain' => $license['domain'],
                'activated_at' => $license['activated_at'],
                'last_validation' => $license['last_validation'],
                'validation_count' => $license['validation_count']
            ];
            
        } catch (Exception $e) {
            error_log("License status error: " . $e->getMessage());
            return ['error' => 'Failed to get license status'];
        }
    }
    
    /**
     * Get installations
     */
    public function getInstallations() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    l.license_key,
                    l.customer_id,
                    c.customer_name,
                    c.customer_email,
                    l.license_type,
                    l.status,
                    l.domain,
                    l.hardware_id,
                    l.activated_at,
                    l.last_heartbeat,
                    l.expiry_date
                FROM licenses l
                LEFT JOIN customers c ON l.customer_id = c.id
                WHERE l.hardware_id IS NOT NULL
                ORDER BY l.last_heartbeat DESC
            ");
            $stmt->execute();
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            error_log("Get installations error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get analytics
     */
    public function getAnalytics() {
        try {
            // License statistics
            $stmt = $this->pdo->prepare("
                SELECT 
                    COUNT(*) as total_licenses,
                    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_licenses,
                    SUM(CASE WHEN hardware_id IS NOT NULL THEN 1 ELSE 0 END) as activated_licenses,
                    SUM(CASE WHEN expiry_date < NOW() THEN 1 ELSE 0 END) as expired_licenses
                FROM licenses
            ");
            $stmt->execute();
            $licenseStats = $stmt->fetch();
            
            // Performance statistics
            $stmt = $this->pdo->prepare("
                SELECT 
                    AVG(execution_time) as avg_execution_time,
                    AVG(memory_usage) as avg_memory_usage,
                    AVG(query_count) as avg_query_count,
                    SUM(slow_queries) as total_slow_queries,
                    SUM(error_count) as total_errors
                FROM performance_logs 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ");
            $stmt->execute();
            $performanceStats = $stmt->fetch();
            
            // Usage statistics
            $stmt = $this->pdo->prepare("
                SELECT 
                    AVG(active_users) as avg_active_users,
                    SUM(total_applications) as total_applications,
                    SUM(new_applications) as new_applications_today,
                    AVG(storage_used) as avg_storage_used,
                    AVG(bandwidth_used) as avg_bandwidth_used
                FROM usage_logs 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ");
            $stmt->execute();
            $usageStats = $stmt->fetch();
            
            return [
                'license_stats' => $licenseStats,
                'performance_stats' => $performanceStats,
                'usage_stats' => $usageStats,
                'generated_at' => date('c')
            ];
            
        } catch (Exception $e) {
            error_log("Analytics error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Encrypt data
     */
    private function encrypt($data) {
        $iv = random_bytes(12);
        $tag = '';
        
        $encrypted = openssl_encrypt(
            $data,
            'aes-256-gcm',
            base64_decode($this->encryptionKey),
            OPENSSL_RAW_DATA,
            $iv,
            $tag
        );
        
        return base64_encode($iv . $tag . $encrypted);
    }
    
    /**
     * Sign data
     */
    private function sign($data) {
        // Simple signature for demo - in production use proper RSA signing
        return base64_encode(hash_hmac('sha256', $data, $this->encryptionKey, true));
    }
    
    /**
     * Store license
     */
    private function storeLicense($licenseKey, $licenseData) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO licenses (
                    license_key, customer_id, customer_name, license_type,
                    max_users, max_applications, expiry_date, features,
                    issued_at, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW())
                ON DUPLICATE KEY UPDATE
                    license_key = VALUES(license_key),
                    customer_id = VALUES(customer_id),
                    customer_name = VALUES(customer_name),
                    license_type = VALUES(license_type),
                    max_users = VALUES(max_users),
                    max_applications = VALUES(max_applications),
                    expiry_date = VALUES(expiry_date),
                    features = VALUES(features),
                    issued_at = VALUES(issued_at),
                    status = 'active',
                    updated_at = NOW()
            ");
            
            $stmt->execute([
                $licenseKey,
                $licenseData['customer_id'],
                $licenseData['customer_name'],
                $licenseData['license_type'],
                $licenseData['max_users'],
                $licenseData['max_applications'],
                $licenseData['expiry_date'],
                json_encode($licenseData['features']),
                $licenseData['issued_at']
            ]);
            
            return true;
        } catch (Exception $e) {
            error_log("License storage error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Log validation
     */
    private function logValidation($licenseKey, $hardwareId, $domain, $version, $success) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO validation_logs (
                    license_key, hardware_id, domain, version, success,
                    ip_address, user_agent, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $licenseKey,
                $hardwareId,
                $domain,
                $version,
                $success ? 1 : 0,
                $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
            ]);
        } catch (Exception $e) {
            error_log("Validation logging error: " . $e->getMessage());
        }
    }
    
    /**
     * Log activation
     */
    private function logActivation($licenseKey, $hardwareId, $domain, $version) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO activation_logs (
                    license_key, hardware_id, domain, version,
                    ip_address, user_agent, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $licenseKey,
                $hardwareId,
                $domain,
                $version,
                $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
            ]);
        } catch (Exception $e) {
            error_log("Activation logging error: " . $e->getMessage());
        }
    }
}
?>