<?php
/**
 * Installation Monitor
 * Monitors installations and their performance
 */

class InstallationMonitor {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Get installation statistics
     */
    public function getInstallationStats() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    COUNT(*) as total_installations,
                    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_installations,
                    SUM(CASE WHEN last_heartbeat > DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 ELSE 0 END) as online_installations,
                    SUM(CASE WHEN last_heartbeat < DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 ELSE 0 END) as offline_installations
                FROM licenses 
                WHERE hardware_id IS NOT NULL
            ");
            $stmt->execute();
            return $stmt->fetch();
            
        } catch (Exception $e) {
            error_log("Installation stats error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get offline installations
     */
    public function getOfflineInstallations() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    l.license_key,
                    l.customer_name,
                    l.domain,
                    l.last_heartbeat,
                    c.customer_email
                FROM licenses l
                LEFT JOIN customers c ON l.customer_id = c.id
                WHERE l.status = 'active' 
                AND l.hardware_id IS NOT NULL
                AND (l.last_heartbeat IS NULL OR l.last_heartbeat < DATE_SUB(NOW(), INTERVAL 24 HOUR))
                ORDER BY l.last_heartbeat DESC
            ");
            $stmt->execute();
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            error_log("Offline installations error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get performance metrics
     */
    public function getPerformanceMetrics() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    AVG(execution_time) as avg_execution_time,
                    AVG(memory_usage) as avg_memory_usage,
                    AVG(query_count) as avg_query_count,
                    SUM(slow_queries) as total_slow_queries,
                    SUM(error_count) as total_errors,
                    COUNT(*) as total_logs
                FROM performance_logs 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ");
            $stmt->execute();
            return $stmt->fetch();
            
        } catch (Exception $e) {
            error_log("Performance metrics error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get usage metrics
     */
    public function getUsageMetrics() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    AVG(active_users) as avg_active_users,
                    SUM(total_applications) as total_applications,
                    SUM(new_applications) as new_applications_today,
                    AVG(storage_used) as avg_storage_used,
                    AVG(bandwidth_used) as avg_bandwidth_used,
                    COUNT(*) as total_logs
                FROM usage_logs 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ");
            $stmt->execute();
            return $stmt->fetch();
            
        } catch (Exception $e) {
            error_log("Usage metrics error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get recent activity
     */
    public function getRecentActivity($limit = 50) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    'validation' as activity_type,
                    license_key,
                    hardware_id,
                    domain,
                    success,
                    created_at
                FROM validation_logs
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                
                UNION ALL
                
                SELECT 
                    'activation' as activity_type,
                    license_key,
                    hardware_id,
                    domain,
                    1 as success,
                    created_at
                FROM activation_logs
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                
                UNION ALL
                
                SELECT 
                    'deactivation' as activity_type,
                    license_key,
                    hardware_id,
                    NULL as domain,
                    1 as success,
                    created_at
                FROM deactivation_logs
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                
                ORDER BY created_at DESC
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            error_log("Recent activity error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get installation health score
     */
    public function getInstallationHealthScore($licenseKey) {
        try {
            // Get recent performance data
            $stmt = $this->pdo->prepare("
                SELECT 
                    AVG(execution_time) as avg_execution_time,
                    AVG(memory_usage) as avg_memory_usage,
                    SUM(slow_queries) as total_slow_queries,
                    SUM(error_count) as total_errors,
                    COUNT(*) as log_count
                FROM performance_logs 
                WHERE license_key = ? 
                AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ");
            $stmt->execute([$licenseKey]);
            $performance = $stmt->fetch();
            
            if (!$performance || $performance['log_count'] == 0) {
                return 0; // No data available
            }
            
            $score = 100;
            
            // Deduct points for performance issues
            if ($performance['avg_execution_time'] > 5) {
                $score -= 20;
            } elseif ($performance['avg_execution_time'] > 2) {
                $score -= 10;
            }
            
            if ($performance['avg_memory_usage'] > 134217728) { // 128MB
                $score -= 15;
            }
            
            if ($performance['total_slow_queries'] > 10) {
                $score -= 15;
            }
            
            if ($performance['total_errors'] > 5) {
                $score -= 20;
            }
            
            return max(0, $score);
            
        } catch (Exception $e) {
            error_log("Health score error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Get installation trends
     */
    public function getInstallationTrends($days = 30) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as new_installations
                FROM licenses 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                GROUP BY DATE(created_at)
                ORDER BY date ASC
            ");
            $stmt->execute([$days]);
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            error_log("Installation trends error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get top performing installations
     */
    public function getTopPerformingInstallations($limit = 10) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    l.license_key,
                    l.customer_name,
                    l.domain,
                    AVG(pl.execution_time) as avg_execution_time,
                    AVG(pl.memory_usage) as avg_memory_usage,
                    SUM(pl.slow_queries) as total_slow_queries,
                    SUM(pl.error_count) as total_errors,
                    COUNT(pl.id) as log_count
                FROM licenses l
                LEFT JOIN performance_logs pl ON l.license_key = pl.license_key
                WHERE l.hardware_id IS NOT NULL
                AND pl.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                GROUP BY l.license_key
                HAVING log_count > 0
                ORDER BY avg_execution_time ASC, total_errors ASC
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            error_log("Top performing installations error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get problematic installations
     */
    public function getProblematicInstallations($limit = 10) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    l.license_key,
                    l.customer_name,
                    l.domain,
                    AVG(pl.execution_time) as avg_execution_time,
                    AVG(pl.memory_usage) as avg_memory_usage,
                    SUM(pl.slow_queries) as total_slow_queries,
                    SUM(pl.error_count) as total_errors,
                    COUNT(pl.id) as log_count
                FROM licenses l
                LEFT JOIN performance_logs pl ON l.license_key = pl.license_key
                WHERE l.hardware_id IS NOT NULL
                AND pl.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                GROUP BY l.license_key
                HAVING log_count > 0
                AND (avg_execution_time > 5 OR total_errors > 5 OR total_slow_queries > 10)
                ORDER BY total_errors DESC, avg_execution_time DESC
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            error_log("Problematic installations error: " . $e->getMessage());
            return [];
        }
    }
}
?>
