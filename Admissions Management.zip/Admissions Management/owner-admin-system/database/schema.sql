-- Owner Admin System Database Schema
-- This file contains all the necessary tables for the owner admin system

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS `owner_admin` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `owner_admin`;

-- System settings table
CREATE TABLE IF NOT EXISTS `system_settings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(100) NOT NULL UNIQUE,
    `setting_value` TEXT,
    `setting_type` ENUM('string', 'boolean', 'integer', 'json') DEFAULT 'string',
    `description` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_setting_key` (`setting_key`)
);

-- Owner users table
CREATE TABLE IF NOT EXISTS `owner_users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `role` ENUM('admin', 'manager', 'viewer') DEFAULT 'viewer',
    `status` ENUM('active', 'inactive') DEFAULT 'active',
    `last_login` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_username` (`username`),
    INDEX `idx_status` (`status`)
);

-- Customers table
CREATE TABLE IF NOT EXISTS `customers` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `customer_name` VARCHAR(255) NOT NULL,
    `customer_email` VARCHAR(255) NOT NULL,
    `customer_phone` VARCHAR(50),
    `company_name` VARCHAR(255),
    `address` TEXT,
    `city` VARCHAR(100),
    `state` VARCHAR(100),
    `country` VARCHAR(100),
    `postal_code` VARCHAR(20),
    `website` VARCHAR(255),
    `industry` VARCHAR(100),
    `company_size` ENUM('small', 'medium', 'large', 'enterprise') DEFAULT 'small',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_customer_email` (`customer_email`),
    INDEX `idx_company_name` (`company_name`)
);

-- Licenses table
CREATE TABLE IF NOT EXISTS `licenses` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `license_key` VARCHAR(500) UNIQUE NOT NULL,
    `customer_id` INT NOT NULL,
    `customer_name` VARCHAR(255) NOT NULL,
    `license_type` ENUM('basic', 'professional', 'enterprise') NOT NULL,
    `max_users` INT NOT NULL DEFAULT 10,
    `max_applications` INT NOT NULL DEFAULT 1000,
    `expiry_date` DATE NOT NULL,
    `features` JSON,
    `hardware_id` VARCHAR(255),
    `domain` VARCHAR(255),
    `version` VARCHAR(20),
    `allowed_domains` JSON,
    `issued_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `activated_at` TIMESTAMP NULL,
    `deactivated_at` TIMESTAMP NULL,
    `last_validation` TIMESTAMP NULL,
    `last_heartbeat` TIMESTAMP NULL,
    `validation_count` INT DEFAULT 0,
    `heartbeat_count` INT DEFAULT 0,
    `status` ENUM('active', 'inactive', 'suspended', 'expired') DEFAULT 'active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE CASCADE,
    INDEX `idx_license_key` (`license_key`),
    INDEX `idx_customer_id` (`customer_id`),
    INDEX `idx_hardware_id` (`hardware_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_expiry_date` (`expiry_date`)
);

-- License events table
CREATE TABLE IF NOT EXISTS `license_events` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `license_key` VARCHAR(500) NOT NULL,
    `event_type` VARCHAR(50) NOT NULL,
    `event_data` JSON,
    `hardware_id` VARCHAR(255),
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`license_key`) REFERENCES `licenses`(`license_key`) ON DELETE CASCADE,
    INDEX `idx_license_key` (`license_key`),
    INDEX `idx_event_type` (`event_type`),
    INDEX `idx_created_at` (`created_at`)
);

-- Validation logs table
CREATE TABLE IF NOT EXISTS `validation_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `license_key` VARCHAR(500) NOT NULL,
    `hardware_id` VARCHAR(255),
    `domain` VARCHAR(255),
    `version` VARCHAR(20),
    `success` BOOLEAN NOT NULL,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_license_key` (`license_key`),
    INDEX `idx_success` (`success`),
    INDEX `idx_created_at` (`created_at`)
);

-- Activation logs table
CREATE TABLE IF NOT EXISTS `activation_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `license_key` VARCHAR(500) NOT NULL,
    `hardware_id` VARCHAR(255),
    `domain` VARCHAR(255),
    `version` VARCHAR(20),
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_license_key` (`license_key`),
    INDEX `idx_created_at` (`created_at`)
);

-- Deactivation logs table
CREATE TABLE IF NOT EXISTS `deactivation_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `license_key` VARCHAR(500) NOT NULL,
    `hardware_id` VARCHAR(255),
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_license_key` (`license_key`),
    INDEX `idx_created_at` (`created_at`)
);

-- Performance logs table
CREATE TABLE IF NOT EXISTS `performance_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `license_key` VARCHAR(500) NOT NULL,
    `hardware_id` VARCHAR(255),
    `domain` VARCHAR(255),
    `version` VARCHAR(20),
    `execution_time` DECIMAL(10,3),
    `memory_usage` BIGINT,
    `query_count` INT,
    `slow_queries` INT,
    `error_count` INT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_license_key` (`license_key`),
    INDEX `idx_created_at` (`created_at`)
);

-- Usage logs table
CREATE TABLE IF NOT EXISTS `usage_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `license_key` VARCHAR(500) NOT NULL,
    `hardware_id` VARCHAR(255),
    `domain` VARCHAR(255),
    `version` VARCHAR(20),
    `active_users` INT,
    `total_applications` INT,
    `new_applications` INT,
    `storage_used` BIGINT,
    `bandwidth_used` BIGINT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_license_key` (`license_key`),
    INDEX `idx_created_at` (`created_at`)
);

-- Tampering logs table
CREATE TABLE IF NOT EXISTS `tampering_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `license_key` VARCHAR(500),
    `attempt_type` VARCHAR(100) NOT NULL,
    `details` TEXT,
    `actual_value` TEXT,
    `expected_value` TEXT,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `request_uri` TEXT,
    `timestamp` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_license_key` (`license_key`),
    INDEX `idx_attempt_type` (`attempt_type`),
    INDEX `idx_timestamp` (`timestamp`)
);

-- File integrity table
CREATE TABLE IF NOT EXISTS `file_integrity` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `file_path` VARCHAR(500) NOT NULL,
    `file_hash` VARCHAR(128) NOT NULL,
    `status` ENUM('active', 'inactive') DEFAULT 'active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_file_path` (`file_path`),
    INDEX `idx_status` (`status`)
);

-- Insert default system settings
INSERT INTO `system_settings` (`setting_key`, `setting_value`, `setting_type`, `description`) VALUES
('license_server_url', 'https://your-domain.com', 'string', 'URL of the license server'),
('notification_email', 'admin@your-domain.com', 'string', 'Email address for notifications'),
('backup_enabled', 'true', 'boolean', 'Enable automatic backups'),
('monitoring_enabled', 'true', 'boolean', 'Enable system monitoring'),
('alert_threshold_execution_time', '5.0', 'string', 'Execution time threshold for alerts (seconds)'),
('alert_threshold_memory_usage', '134217728', 'string', 'Memory usage threshold for alerts (bytes)'),
('alert_threshold_slow_queries', '10', 'string', 'Slow queries threshold for alerts'),
('alert_threshold_errors', '5', 'string', 'Error count threshold for alerts (per hour)'),
('encryption_key', '', 'string', 'Encryption key for license data'),
('session_timeout', '30', 'string', 'Session timeout in minutes'),
('require_https', 'true', 'boolean', 'Require HTTPS connections'),
('enable_audit_log', 'true', 'boolean', 'Enable audit logging');

-- Insert default admin user (password: admin123)
INSERT INTO `owner_users` (`username`, `password_hash`, `role`, `status`) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active');