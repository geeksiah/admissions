<?php
/**
 * Owner Admin Dashboard
 */

// Get analytics data
$licenseServer = new LicenseServer($pdo);
$analytics = $licenseServer->getAnalytics();

// Get installation monitor data
$installationMonitor = new InstallationMonitor($pdo);
$installationStats = $installationMonitor->getInstallationStats();
$offlineInstallations = $installationMonitor->getOfflineInstallations();
$performanceMetrics = $installationMonitor->getPerformanceMetrics();
$usageMetrics = $installationMonitor->getUsageMetrics();

// Get revenue tracker data
$revenueTracker = new RevenueTracker($pdo);
$revenueStats = $revenueTracker->getRevenueStats();
$subscriptionMetrics = $revenueTracker->getSubscriptionMetrics();
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Owner Admin Dashboard</h2>
                <div>
                    <span class="badge bg-success">System Online</span>
                    <small class="text-muted ms-2">Last updated: <?php echo date('Y-m-d H:i:s'); ?></small>
                </div>
            </div>
            
            <!-- Key Metrics Row -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card bg-primary text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h4><?php echo $analytics['license_stats']['total_licenses'] ?? 0; ?></h4>
                                    <p class="mb-0">Total Licenses</p>
                                </div>
                                <div class="align-self-center">
                                    <i class="fas fa-key fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-success text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h4><?php echo $installationStats['active_installations'] ?? 0; ?></h4>
                                    <p class="mb-0">Active Installations</p>
                                </div>
                                <div class="align-self-center">
                                    <i class="fas fa-server fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-info text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h4><?php echo $installationStats['online_installations'] ?? 0; ?></h4>
                                    <p class="mb-0">Online Now</p>
                                </div>
                                <div class="align-self-center">
                                    <i class="fas fa-wifi fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-warning text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h4><?php echo $installationStats['offline_installations'] ?? 0; ?></h4>
                                    <p class="mb-0">Offline</p>
                                </div>
                                <div class="align-self-center">
                                    <i class="fas fa-exclamation-triangle fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Performance Metrics Row -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h5><?php echo number_format($performanceMetrics['avg_execution_time'] ?? 0, 2); ?>s</h5>
                                    <p class="mb-0 text-muted">Avg Response Time</p>
                                </div>
                                <div class="align-self-center">
                                    <i class="fas fa-clock fa-2x text-primary"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h5><?php echo $this->formatBytes($performanceMetrics['avg_memory_usage'] ?? 0); ?></h5>
                                    <p class="mb-0 text-muted">Avg Memory Usage</p>
                                </div>
                                <div class="align-self-center">
                                    <i class="fas fa-memory fa-2x text-info"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h5><?php echo $performanceMetrics['total_errors'] ?? 0; ?></h5>
                                    <p class="mb-0 text-muted">Errors (24h)</p>
                                </div>
                                <div class="align-self-center">
                                    <i class="fas fa-exclamation-circle fa-2x text-danger"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h5><?php echo number_format($usageMetrics['avg_active_users'] ?? 0, 0); ?></h5>
                                    <p class="mb-0 text-muted">Avg Active Users</p>
                                </div>
                                <div class="align-self-center">
                                    <i class="fas fa-users fa-2x text-success"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Charts Row -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">License Distribution</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="licenseChart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Installation Status</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="statusChart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activity and Alerts -->
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Recent Activity</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Time</th>
                                            <th>Activity</th>
                                            <th>Customer</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $recentActivity = $installationMonitor->getRecentActivity(10);
                                        foreach ($recentActivity as $activity):
                                        ?>
                                        <tr>
                                            <td><?php echo date('H:i:s', strtotime($activity['created_at'])); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $activity['activity_type'] === 'validation' ? 'primary' : ($activity['activity_type'] === 'activation' ? 'success' : 'warning'); ?>">
                                                    <?php echo ucfirst($activity['activity_type']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo htmlspecialchars($activity['domain'] ?? 'Unknown'); ?></td>
                                            <td>
                                                <?php if ($activity['activity_type'] === 'validation'): ?>
                                                    <span class="badge bg-<?php echo $activity['success'] ? 'success' : 'danger'; ?>">
                                                        <?php echo $activity['success'] ? 'Success' : 'Failed'; ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-success">Success</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">System Alerts</h5>
                        </div>
                        <div class="card-body">
                            <?php if (count($offlineInstallations) > 0): ?>
                                <div class="alert alert-warning">
                                    <h6><i class="fas fa-exclamation-triangle"></i> Offline Installations</h6>
                                    <p class="mb-0"><?php echo count($offlineInstallations); ?> installations are offline</p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (($performanceMetrics['total_errors'] ?? 0) > 10): ?>
                                <div class="alert alert-danger">
                                    <h6><i class="fas fa-exclamation-circle"></i> High Error Rate</h6>
                                    <p class="mb-0"><?php echo $performanceMetrics['total_errors']; ?> errors in the last 24 hours</p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (($analytics['license_stats']['expired_licenses'] ?? 0) > 0): ?>
                                <div class="alert alert-info">
                                    <h6><i class="fas fa-clock"></i> Expired Licenses</h6>
                                    <p class="mb-0"><?php echo $analytics['license_stats']['expired_licenses']; ?> licenses have expired</p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (count($offlineInstallations) == 0 && ($performanceMetrics['total_errors'] ?? 0) <= 10 && ($analytics['license_stats']['expired_licenses'] ?? 0) == 0): ?>
                                <div class="alert alert-success">
                                    <h6><i class="fas fa-check-circle"></i> All Systems Normal</h6>
                                    <p class="mb-0">No alerts at this time</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// License Distribution Chart
const licenseCtx = document.getElementById('licenseChart').getContext('2d');
new Chart(licenseCtx, {
    type: 'doughnut',
    data: {
        labels: ['Basic', 'Professional', 'Enterprise'],
        datasets: [{
            data: [
                <?php echo $subscriptionMetrics['subscription_breakdown'][0]['count'] ?? 0; ?>,
                <?php echo $subscriptionMetrics['subscription_breakdown'][1]['count'] ?? 0; ?>,
                <?php echo $subscriptionMetrics['subscription_breakdown'][2]['count'] ?? 0; ?>
            ],
            backgroundColor: [
                '#007bff',
                '#28a745',
                '#ffc107'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

// Installation Status Chart
const statusCtx = document.getElementById('statusChart').getContext('2d');
new Chart(statusCtx, {
    type: 'bar',
    data: {
        labels: ['Online', 'Offline', 'Total'],
        datasets: [{
            label: 'Installations',
            data: [
                <?php echo $installationStats['online_installations'] ?? 0; ?>,
                <?php echo $installationStats['offline_installations'] ?? 0; ?>,
                <?php echo $installationStats['total_installations'] ?? 0; ?>
            ],
            backgroundColor: [
                '#28a745',
                '#dc3545',
                '#6c757d'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Auto-refresh dashboard every 5 minutes
setInterval(function() {
    location.reload();
}, 300000);
</script>

<?php
// Helper function for formatting bytes
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, $precision) . ' ' . $units[$i];
}
?>
